import data
import os

import datasim

################### trace data #####################

# create zero data file with same source position, rz=500, rx=[2000,6000]
data.rechdr(file='d11.su',nt=626,dt=8.0,ntr=201,
                rx=2000.0,rz=1000.0,sx=3000,sz=3000,drx=20.0,
                delrt=0, nshot=11, dsx=200)

os.system('/bin/cp d11.su dh11.su')

data.rechdr(file='u11.su', nt=251, dt=8.0, ntr=201,
                rx=2000.0,rz=1000.0,sx=3000,sz=3000,drx=20.0,
                delrt=-1000, nshot=11, dsx=200)

data.bpfiltgather(file='w11.su', nt=251, dt=8.0, s=1000,
                      f1=1.0, f2=2.5, f3=7.5, f4=12.5, ntr=11,
                      sxstart=3000, szstart=3000, dsx=200, dsz=0)

#################### grid data #########################

data.model(bulkfile='m.rsf', bulk=4.0, nx=401, nz=201, dx=20, dz=20,
               lensfac=0.5, lensradd=0.4)

data.model(bulkfile='m0.rsf', bulk=4.0, nx=401, nz=201, dx=20, dz=20,
               lensfac=1.0)

#################### simulations #######################


datasim.asgsim('m.rsf', 'd11.su', 'bym.rsf', 'w11.su', 
                   cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,
                   nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
                   boundstest=True, noisy=True, partask=0)

datasim.asgsim('m0.rsf', 'dh11.su', 'bym.rsf', 'w11.su', 
                   cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,
                   nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
                   boundstest=True, noisy=True, partask=0)


















