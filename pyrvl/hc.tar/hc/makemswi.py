import linalg
import msmswi

# mswi starting at m0
# inputs: 'm0.rsf', 'd11.su', 'u11.su', 'bym.rsf', 'w11.su'
# outputs: 'mest11.rsf', 'uest11.su'

try:
    if not linalg.copy('m0.rsf','mest11.rsf'):
        raise Exception('copy m0 to mestfwi0 failed')
    if not linalg.copy('u11.su','uest11.su'):
        raise Exception('copy m0 to mestfwi0 failed')
    msmswi.mswiopt('mest11.rsf', 'uest11.su',
            'm0.rsf', 'd11.su', 'u11.su', 'bym.rsf', 'w11.su', 
            order=2, sampord=1, nsnaps=20,\
            cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,\
            nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
            boundstest=True, noisy=False, partask=0,
            rect1=10, rect2=10, repeat=2,
            alpha=0.0001, sigma=0.00001, rho=0.0025, kmax=1000, verbose=0,
            descmax=12, desceps=0.01, descverbose=1, descout='mswi.txt',
            lsmax=10, mured=0.5, muinc=1.8, gammared=0.1, gammainc=0.9,
            lsverbose=1)

except Exception as ex:
    print(ex)
    raise Exception('called from makemswi.py')

