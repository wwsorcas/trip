import linalg
import fwi

# fwi starting at mest11.rsf
# required inputs: mest11.rsf. d11.rsf, bym.rsf, w11.rsf
# output: mestfwi0.rsf

try:
    if not linalg.copy('mest11.rsf','mestfwi.rsf'):
        raise Exception('copy m0 to mestfwi0 failed')
    fwi.fwiopt('mestfwi.rsf', 'mest11.rsf', 'd11.su', 'bym.rsf', 'w11.su',
               order=2, sampord=1, nsnaps=20,\
               cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,\
               nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
               boundstest=True, noisy=True, partask=0,
               rect1=10, rect2=10, repeat=2,
               descmax=12, desceps=0.01, descverbose=1, descout='fwi.txt',
               lsmax=10, mured=0.5, muinc=1.8, gammared=0.1, gammainc=0.9,
               lsverbose=1)

except Exception as ex:
    print(ex)
    raise('called fromm makefwi.py')

