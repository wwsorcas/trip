import linalg
import datasim

try:
    if not linalg.copy('d11.su', 'dest11.su'):
        raise Exception('copy d11 to dest11 failed')
    datasim.asgsim('mest11.rsf', 'dest11.su', 'bym.rsf', 'w11.su', 
            cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,
            nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
            boundstest=True, noisy=True, partask=0)
    if not linalg.copy('dest11.su', 'residest11.su'):
        raise Exception('copy dest11 to residest11 failed')
    if not linalg.lincomb(-1.0,'d11.su','residest11.su'):
        raise Exception('lincomb failed')
except Exception as ex:
    print(ex)
    raise Exception('called from makeresid11')
