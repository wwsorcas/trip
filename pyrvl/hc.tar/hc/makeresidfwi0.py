import linalg
import datasim

# compute residual at stopping point of fwi from m0
# inputs: mestfwi0.rsf, bym.rsf, w11.su
# outputs: dfwi0.su, residfwi0.su

try:
    if not linalg.copy('d11.su', 'dfwi0.su'):
        raise Exception('linalg.copy d11 to dfwi0 failed')
    datasim.asgsim('mestfwi0.rsf', 'dfwi0.su', 'bym.rsf', 'w11.su', 
                   cfl=0.5, cmin=1.0, cmax=3.0,dmin=0.8, dmax=3.0,
                   nl1=250, nr1=250, nl2=250, nr2=250, pmlampl=1.0,
                   boundstest=True, noisy=True, partask=0)
    if not linalg.copy('dfwi0.su', 'residfwi0.su'):
        raise Exception('linalg.copy dfwi0 to residfwi0 failed')
    if not linalg.lincomb(-1.0,'d11.su','residfwi0.su')
        raise Exception('linalg.lincomb failed')

except Exception as ex:
    print(ex)
    raise Exception('called from makeresidfwi0.py')
